alert("Welcome to Crafted Memories");

const button = document.getElementById('myButton');
button.addEventListener('click', function() {
  alert('Button clicked!');
});


